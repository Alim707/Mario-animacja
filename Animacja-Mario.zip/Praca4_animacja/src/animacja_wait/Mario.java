package animacja_wait;
/**
 * Enumeracja do rozpoznawania stanu biegu Maria.
 * @author algie_000
 * 
 */
public enum Mario {
	STOP,MIEDZY,KROK

}
